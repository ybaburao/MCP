package com.cts.email.mc.service;
import static com.cts.email.mc.config.AwsClientConfiguration.sesClient;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.lambda.runtime.events.SQSEvent.MessageAttribute;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;

public class EmailService {
	private EmailService() {
  }

  private static Logger log = LoggerFactory.getLogger(EmailService.class);
  private static final String FROM = "ybaburao@gmail.com";
  private static final String SUBJECT = "Welcome to Amazon User Registration";
  private static final String EMAIL_ATTRIBUTE = "email";
  private static final String FIRST_NAME_ATTRIBUTE = "firstName";
  static final String CONFIGSET = "ConfigSet";
  private static final String USER_REGISTER_EMAIL_TEMPLATE = "<h2>Dear %s,</h2><br><p>Thanks for your registration.<br><p>Please Login with unique permament-access-code : <b>[%s]</b>.<br><p>"
  		+ "This is auto-generated email, kindly donot reply to this. In case of any queries, "
  		+ "Please contact here <a href=\"http://aws.amazon.com/\">AWS</a><br><br><p>Sincerely,<br><p>The Amazon Web Services";

	/*
	 * private static final String USER_EMAIL_TEMPLATE =
	 * "<h1>Amazon SES test (AWS SDK for Java)</h1>" +
	 * "<p>This email was sent with <a href='https://aws.amazon.com/ses/'>" +
	 * "Amazon SES</a> using the <a href='https://aws.amazon.com/sdk-for-java/'>" +
	 * "AWS SDK for Java</a>";
	 */
  public static void sendEmail(Map<String, MessageAttribute> messageAttributes) {
        try {
             String emailAddress = messageAttributes.get(EMAIL_ATTRIBUTE).getStringValue();
             log.info("Start sendEmail Email for [{}]", emailAddress);
             SendEmailRequest request = new SendEmailRequest()
                        .withDestination(
                                  new Destination().withToAddresses(emailAddress))
                        .withMessage(new Message()
                                  .withBody(new Body().withHtml(new Content().withCharset(UTF_8.toString())
                                             .withData(selectAndFillTemplate(messageAttributes))))
                                  .withSubject(new Content().withCharset(UTF_8.toString()).withData(SUBJECT)))
                        .withSource(FROM);
             log.info("Before Sending Email to Destination:[{}]", request.getDestination());
             log.info("Before Sending Email message: [{}]", request.getMessage());
             log.info("Before Sending Email source [{}]", request.getSource());
             
             sesClient().sendEmail(request);
             log.info("Email Sent Successfully");
        } catch (Exception ex) {
             log.error("The email was not sent. Error message: {}", ex.getMessage());
        }
  }


 private static String selectAndFillTemplate(Map<String, MessageAttribute> messageAttributes) {
		/*
		 * return String.format(USER_EMAIL_TEMPLATE,
		 * messageAttributes.get(FIRST_NAME_ATTRIBUTE).getStringValue());
		 */
	 return String.format(USER_REGISTER_EMAIL_TEMPLATE,messageAttributes.get(FIRST_NAME_ATTRIBUTE).getStringValue(),generatePermamentAccessCode());
	 //return String.format(USER_REGISTER_EMAIL_TEMPLATE);
  }
 public static String generatePermamentAccessCode() {
     return UUID.randomUUID().toString();

}
}
