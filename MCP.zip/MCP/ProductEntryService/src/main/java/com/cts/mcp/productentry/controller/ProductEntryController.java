package com.cts.mcp.productentry.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.mcp.productentry.model.Product;
import com.cts.mcp.productentry.service.ProductEntryService;
@RestController
@RequestMapping("/product")
public class ProductEntryController {
	@Autowired
	private ProductEntryService productEntryService;
	@RequestMapping("/add/{product}")
	public Product addProduct(@RequestBody Product product) {
		productEntryService.addProduct(product);
		return product;
	}
	@RequestMapping("/update/{product}")
	public Product updateProduct(@RequestBody Product product) {
		productEntryService.updateProduct(product);
		return product;
	}
	@RequestMapping("/delete")
	public Product deleteProduct(@RequestParam String productId) {
		productEntryService.deleteProduct(productId);
		return null;
	}


}
