package com.cts.mcp.productentry.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.cts.mcp.productentry.model.Product;
import com.cts.mcp.productentry.model.ProductEntryResponse;
import com.cts.mcp.productentry.repository.ProductEntryRepository;

public class ProductEntryService {
	private static final Logger LOGGER = LogManager.getLogger(ProductEntryService.class);
	@Autowired
	private ProductEntryRepository productEntryRepository;
	public ProductEntryResponse addProduct(Product product) {
		boolean flag = true;
		ProductEntryResponse productEntryResponse = new ProductEntryResponse();

		if ((product.getProductName()).length() == 0) {
			LOGGER.info("Product name cannot be blank");
			productEntryResponse.setMessage("Product name cannot be blank");
			flag = false;
		} else if ((product.getStock()) == 0) {
			LOGGER.info("Stock cannot be null");
			productEntryResponse.setMessage("Stock cannot be null");
			flag = false;
		} else if ((product.getPrice()) == 0) {
			LOGGER.info("Price cannot be null");
			productEntryResponse.setMessage("Price cannot be null");
			flag = false;
		} else if ((product.getOffer()) == 0) {
			LOGGER.info("Offer cannot be null");
			productEntryResponse.setMessage("Offer cannot be null");
			flag = false;
		} 
		if(flag==true) {
			productEntryResponse = productEntryRepository.saveOrUpdateProduct(product);
		}
		return productEntryResponse;
	}
	public ProductEntryResponse updateProduct(Product product) {
		boolean flag = true;
		ProductEntryResponse productEntryResponse = new ProductEntryResponse();

		if ((product.getProductName()).length() == 0) {
			LOGGER.info("Product name cannot be blank");
			productEntryResponse.setMessage("Product name cannot be blank");
			flag = false;
		} else if ((product.getStock()) == 0) {
			LOGGER.info("Stock cannot be null");
			productEntryResponse.setMessage("Stock cannot be null");
			flag = false;
		} else if ((product.getPrice()) == 0) {
			LOGGER.info("Price cannot be null");
			productEntryResponse.setMessage("Price cannot be null");
			flag = false;
		} else if ((product.getOffer()) == 0) {
			LOGGER.info("Offer cannot be null");
			productEntryResponse.setMessage("Offer cannot be null");
			flag = false;
		} 
		if(flag==true) {
			productEntryResponse = productEntryRepository.saveOrUpdateProduct(product);
		}
		return productEntryResponse;
	}

	public ProductEntryResponse deleteProduct(String productId) {
		boolean flag = true;
		ProductEntryResponse productEntryResponse = new ProductEntryResponse();

		if (productId==null) {
			LOGGER.info("ProductId cannot be null");
			productEntryResponse.setMessage("ProductId cannot be null");
			flag = false;
		}  
		if(flag==true) {
			productEntryResponse = productEntryRepository.deleteProduct(productId);
		}
		return productEntryResponse;
	}
}
