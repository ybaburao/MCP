package com.cts.mcp.UserRegistrationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
