package com.cts.mcp.userregistration.service.repository;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.cts.mcp.userregistration.model.User;
import com.cts.mcp.userregistration.model.UserRegistrationResponse;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserRegistrationRepository {
	ObjectMapper mapper = new ObjectMapper();

	public UserRegistrationResponse saveOrUpdateUser(User user) {
		UserRegistrationResponse userRegistrationResponse = null;
		ArrayList<User> existingUser = null;
		InputStream input;
		try {
			input = new FileInputStream("D:\\313474\\MCP\\UserRegistrationService\\src\\main\\resources\\User.json");
			if (input.available() == 0) {
				userRegistrationResponse = new UserRegistrationResponse();
				writeJson(Arrays.asList(user));
				userRegistrationResponse.setMessage("Succefully Created User Json File");
			} else {
				System.out.println("Json file is not empty ");
				userRegistrationResponse = new UserRegistrationResponse();
				List<User> usersList = Arrays.asList(mapper.readValue(input, User[].class));
				existingUser = new ArrayList<>(usersList);
				updateJson(existingUser, user);
				userRegistrationResponse.setMessage("Succefully Updated User Json File");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userRegistrationResponse;
	}


	public void writeJson(List<User> user)
			throws JsonGenerationException, JsonMappingException, FileNotFoundException, IOException {
		mapper.writeValue(new FileOutputStream("D:\\313474\\MCP\\UserRegistrationService\\src\\main\\resources\\User.json"), user);
	}

	public void updateJson(ArrayList<User> existingUsers, User newUser) {
		System.out.println("UpdateJson method......");
		int initialSize = existingUsers.size();
		System.out.println(" Existing Json objects count " + initialSize);

		boolean[] flag = { true };
		flag[0] = false;

		if (existingUsers.size() == 0) {
			System.out.println("Json file is empty duplicate");
			existingUsers.add(newUser);
		} else {

			System.out.println(" update json method else block ");
			existingUsers.forEach(existingUser -> {
				if (existingUser.getUserId().equals(newUser.getUserId())) {
					System.out.println(" User already exists so updating it ");
					existingUser.setFirstName(newUser.getFirstName());
					existingUser.setLastName(newUser.getLastName());
					existingUser.setDob(newUser.getDob());
					existingUser.setEmail(newUser.getEmail());
					flag[0] = true;
				}

			});

			System.out.println(" flage is " + flag[0]);
			if (flag[0] == false) {
				System.out.println("object doesn't exists in json adding it to json ");
				existingUsers.addAll(Arrays.asList(newUser));
			}
		}

		try {
			mapper.writeValue(new FileOutputStream("D:\\313474\\MCP\\UserRegistrationService\\src\\main\\resources\\User.json"),
					existingUsers);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
