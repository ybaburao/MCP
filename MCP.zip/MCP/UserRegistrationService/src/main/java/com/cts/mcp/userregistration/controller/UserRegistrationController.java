package com.cts.mcp.userregistration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.mcp.userregistration.model.User;
import com.cts.mcp.userregistration.service.UserRegistrationService;

@RestController
@RequestMapping("/user")
public class UserRegistrationController {

	@Autowired
	private UserRegistrationService userRegistrationService;

	@RequestMapping("/createUser")
	public User addUser(@RequestBody User userobject) {
		userRegistrationService.addUser(userobject);
		return userobject;
	}

	@RequestMapping("/updateUser")
	public User updateUser(@RequestBody User userobject) {
		userRegistrationService.updateUser(userobject);
		return userobject;
	}
}
