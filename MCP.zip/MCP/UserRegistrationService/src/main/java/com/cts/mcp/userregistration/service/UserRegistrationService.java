package com.cts.mcp.userregistration.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.cts.mcp.userregistration.model.User;
import com.cts.mcp.userregistration.model.UserRegistrationResponse;
import com.cts.mcp.userregistration.service.repository.UserRegistrationRepository;

public class UserRegistrationService {
	private static final Logger LOGGER = LogManager.getLogger(UserRegistrationService.class);
	@Autowired
	private UserRegistrationRepository userRegistrationRepository;
	public UserRegistrationResponse addUser(User user) {
		boolean flag = true;
		UserRegistrationResponse userRegistrationResponse = new UserRegistrationResponse();

		if ((user.getFirstName()).length() == 0) {
			LOGGER.info("User FirstName cannot be blank");
			userRegistrationResponse.setMessage("User FirstName cannot be blank");
			flag = false;
		} else if ((user.getLastName()).length() == 0) {
			LOGGER.info("User LaseName cannot be null");
			userRegistrationResponse.setMessage("User LaseName cannot be null");
			flag = false;
		} else if ((user.getEmail()).length() == 0) {
			LOGGER.info("User Email Address cannot be null");
			userRegistrationResponse.setMessage("User Email Address cannot be null");
			flag = false;
		} 
		if(flag==true) {
			userRegistrationResponse = userRegistrationRepository.saveOrUpdateUser(user);
		}
		return userRegistrationResponse;
	}
	public UserRegistrationResponse updateUser(User user) {
		boolean flag = true;
		UserRegistrationResponse userRegistrationResponse = new UserRegistrationResponse();

		if ((user.getFirstName()).length() == 0) {
			LOGGER.info("User FirstName cannot be blank");
			userRegistrationResponse.setMessage("User FirstName cannot be blank");
			flag = false;
		} else if ((user.getLastName()).length() == 0) {
			LOGGER.info("User LaseName cannot be null");
			userRegistrationResponse.setMessage("User LaseName cannot be null");
			flag = false;
		} else if ((user.getEmail()).length() == 0) {
			LOGGER.info("User Email Address cannot be null");
			userRegistrationResponse.setMessage("User Email Address cannot be null");
			flag = false;
		} 
		if(flag==true) {
			userRegistrationResponse = userRegistrationRepository.saveOrUpdateUser(user);
		}
		return userRegistrationResponse;
	}


}
