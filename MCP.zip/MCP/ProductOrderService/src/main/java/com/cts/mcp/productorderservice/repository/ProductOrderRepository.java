package com.cts.mcp.productorderservice.repository;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import com.cts.mcp.productorderservice.model.Product;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProductOrderRepository {
	public String addProductToCart(Product product) {
		ObjectMapper mapper = new ObjectMapper();
		String message = null;
		try {
		mapper.writeValue(new FileOutputStream("D:\\MCP\\ProductOrderService\\src\\main\\resources\\CartData.json"), product);
		message = "Product Successfully Added To The Card";
		}catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}
	public List<Product> getProductFromCart() {
		
		List<Product> cartList=null;
		ObjectMapper mapper = new ObjectMapper();		
		
		InputStream input;
		try {
			input = new FileInputStream("D:\\MCP\\ProductOrderService\\src\\main\\resources\\CartData.json");
			if (input.available() == 0) {
			} else {
				cartList = Arrays.asList(mapper.readValue(input, Product[].class));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cartList;
	}


}
