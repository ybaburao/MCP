package com.cts.mcp.productorderservice.service;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cts.mcp.productorderservice.model.Product;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProductOrderService {
	public Product getProductById(int productId) {
		Product orderedProduct = null;
		ObjectMapper mapper = new ObjectMapper();

		CopyOnWriteArrayList<Product> existingProducts = new CopyOnWriteArrayList<>();
		InputStream input;
		try {
			input = new FileInputStream("D:\\MCP\\ProductEntryService\\src\\main\\resources\\Product.json");
			if (input.available() == 0) {
			} else {
				List<Product> usersList = Arrays.asList(mapper.readValue(input, Product[].class));
				existingProducts = new CopyOnWriteArrayList<>(usersList);
				Iterator<Product> existingProductsIterator = existingProducts.iterator();

				while (existingProductsIterator.hasNext()) {
					Product product = (Product) existingProductsIterator.next();
					if (product.getProductId() == (productId)) {
						orderedProduct = product;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return orderedProduct;
	}

}

