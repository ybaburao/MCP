package com.cts.mcp.productorderservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cts.mcp.productorderservice.model.Product;
import com.cts.mcp.productorderservice.repository.ProductOrderRepository;
import com.cts.mcp.productorderservice.service.ProductOrderService;

public class ProductOrderController {
	@Autowired
	ProductOrderService productOrderService;
	@Autowired
	ProductOrderRepository productOrderRepository;
	@RequestMapping("/addToCart/{productId}")
	public String addProductToCart(@PathVariable int productId) {
		
		Product product=productOrderService.getProductById(productId);
		String message = productOrderRepository.addProductToCart(product);
		return message;
	}
	@RequestMapping("/listCart")
	public List<Product> listCartProducts() {
		List<Product> cartProducts = productOrderRepository.getProductFromCart();
		return cartProducts;
	}
}
