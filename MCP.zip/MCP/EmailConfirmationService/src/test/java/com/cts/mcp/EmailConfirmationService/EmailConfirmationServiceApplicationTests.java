package com.cts.mcp.EmailConfirmationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailConfirmationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
