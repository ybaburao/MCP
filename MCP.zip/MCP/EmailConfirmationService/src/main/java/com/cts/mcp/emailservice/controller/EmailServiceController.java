package com.cts.mcp.emailservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.mcp.emailservice.model.EmailMessage;
import com.cts.mcp.emailservice.service.EmailService;

@RestController
@RequestMapping("/email")
public class EmailServiceController {
	@Autowired
	private EmailService emailService;
	
	@RequestMapping("/send")
	public String sendEmail(@RequestBody EmailMessage emailMessage) {
		String messageSend= null;
		try {
			messageSend = emailService.sendMail(emailMessage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return messageSend;
	}
}
