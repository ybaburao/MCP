package com.cts.mcp.emailservice.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailConfirmationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailConfirmationServiceApplication.class, args);
	}

}
