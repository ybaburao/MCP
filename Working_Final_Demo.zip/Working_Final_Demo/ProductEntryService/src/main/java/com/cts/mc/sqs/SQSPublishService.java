package com.cts.mc.sqs;

import static com.cts.mc.config.AwsClientConfiguration.s3Client;
import static com.cts.mc.config.AwsClientConfiguration.sqsClient;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.cts.mc.product.vo.Product;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

public class SQSPublishService {

	private SQSPublishService() {
		// Utility classes should not have public constructors (squid:S1118)
	}

	private static final String TYPE_ATTRIBUTE = "type";
	private static final String OFFER_TYPE = "register-product";
	private static final String OFFER_ATTRIBUTE = "offer";
	private static final String PRODUCT_NAME_ATTRIBUTE = "product";
	private static final String ATTRIBUTE_DATATYPE = "String";
	private static Logger log = LoggerFactory.getLogger(SQSPublishService.class);
	private static final String SQS_QUEUE_URL = "https://sqs.us-east-1.amazonaws.com/926374759404/ProductEntryServiceSQS";
	private static final String S3_PRODUCT_BUCKET = "productonlineorderservice";
	private static final String S3_PRODUCT_FILE_KEY = "product.json";
	private static final String TEMP_FILE_PATH = "/tmp/product.json";
	private static Gson gson = new Gson();
	public static void publishToSQS(Product product) {
		log.info("Creating the message Request to be published to Queue.");
		SendMessageRequest messageRequest = new SendMessageRequest().withQueueUrl(SQS_QUEUE_URL)
				.withMessageAttributes(fillMessageAttributes(product)).withDelaySeconds(5)
				.withMessageBody(product.getName());
		// publish the message with SQS Client
		sqsClient().sendMessage(messageRequest);
		log.info("Successfully Published to Queue ");
		uploadToS3(product);
		log.info("Successfully uploaded to S3 ");
	}

	private static Map<String, MessageAttributeValue> fillMessageAttributes(Product product) {
		MessageAttributeValue typeAttrVal = new MessageAttributeValue().withStringValue(OFFER_TYPE)
				.withDataType(ATTRIBUTE_DATATYPE);
		MessageAttributeValue emailAttrVal = new MessageAttributeValue().withStringValue(product.getOffer())
				.withDataType(ATTRIBUTE_DATATYPE);
		MessageAttributeValue productNameAttrVal = new MessageAttributeValue().withStringValue(product.getName())
				.withDataType(ATTRIBUTE_DATATYPE);
		Object[][] messageAttributesMap = new Object[][] { { TYPE_ATTRIBUTE, typeAttrVal },
				{ OFFER_ATTRIBUTE, emailAttrVal }, { PRODUCT_NAME_ATTRIBUTE, productNameAttrVal } };
		return Stream.of(messageAttributesMap)
				.collect(Collectors.toMap(data -> (String) data[0], data -> (MessageAttributeValue) data[1]));

	}
	public static boolean uploadToS3(Product product) {
		boolean isOk = false;
		try {
			log.info("s3Object:: Test Test " );
			// Get the existing object from Bucket.
			S3Object s3Object = s3Client().getObject(S3_PRODUCT_BUCKET, S3_PRODUCT_FILE_KEY);
			// parse the s3Object.
			log.info("s3Object::"+s3Object);
			List<Product> dataToModify = readS3Object(s3Object);
			log.info("dataToModify::"+dataToModify);
			dataToModify.add(product);
			File file = writeToTempFile(dataToModify, new File(TEMP_FILE_PATH));
			s3Client().deleteObject(S3_PRODUCT_BUCKET, S3_PRODUCT_FILE_KEY);
			// Finally upload the modified file back to S3.
			log.info("Uploading the modified Json file to S3 with bucketname [{}] and key [{}]", S3_PRODUCT_BUCKET,
					S3_PRODUCT_FILE_KEY);
			s3Client().putObject(S3_PRODUCT_BUCKET, S3_PRODUCT_FILE_KEY, file);
			log.info("File Successfully Uploaded [{}]", file);
			isOk = true;
		} catch (AmazonServiceException e) {
			log.error("Unable to either parse the product.json or its not available");
		} catch (Exception e) {
			log.error("Unexpected Exception occurred. Check the previous logs for more info.");
		}
		return isOk;
	}

	private static List<Product> readS3Object(S3Object s3Object) {
		try {
			return gson.fromJson(new InputStreamReader(s3Object.getObjectContent(), UTF_8), List.class);
		} catch (JsonSyntaxException | JsonIOException e) {
			log.error("Unable to parse the S3 Object");
		}
		return Collections.emptyList();
	}

	private static File writeToTempFile(List<Product> productList, File tempFile) {
		try (FileWriter fileWriter = new FileWriter(tempFile)) {
			gson.toJson(productList, fileWriter);
		} catch (IOException | JsonIOException e) {
			log.error("Unable to create temporary File");
		}
		return tempFile;

	}



}
