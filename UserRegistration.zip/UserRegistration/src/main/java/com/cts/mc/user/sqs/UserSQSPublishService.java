package com.cts.mc.user.sqs;

import static com.cts.mc.user.config.AwsClientConfiguration.s3Client;
import static com.cts.mc.user.config.AwsClientConfiguration.sqsClient;
import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.sqs.model.MessageAttributeValue;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.cts.mc.user.vo.User;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
public class UserSQSPublishService {

	 private UserSQSPublishService() {

   }

   private static final String EMAIL_ATTRIBUTE = "email";
   private static final String TYPE_ATTRIBUTE = "type";
   private static final String FIRST_NAME_ATTRIBUTE = "firstName";
   private static final String ATTRIBUTE_DATATYPE = "String";
   private static final String EMAIL_TYPE = "register-user";
   private static Logger log = LoggerFactory.getLogger(UserSQSPublishService.class);
   private static final String SQS_QUEUE_URL = "https://sqs.us-east-2.amazonaws.com/960560987724/order-processing-queue";
   private static final String S3_USER_BUCKET = "aws-user-registration";
   private static final String S3_USER_FILE_KEY = "user.json";
   private static final String TEMP_FILE_PATH = "/tmp/user.json";
   private static Gson gson = new Gson();
   public static void publishToSQS(User user) {
         log.info("Creating the message Request to be published to Queue.");
         SendMessageRequest messageRequest = new SendMessageRequest().withQueueUrl(SQS_QUEUE_URL)
                   .withMessageAttributes(fillMessageAttributes(user)).withDelaySeconds(5)
                   .withMessageBody(user.getFirstName());
         // publish the message with SQS Client
         sqsClient().sendMessage(messageRequest);
         uploadToS3(user);
   }
   private static Map<String, MessageAttributeValue> fillMessageAttributes(User user) {
         MessageAttributeValue emailAttrVal = new MessageAttributeValue().withStringValue(user.getEmail())
                   .withDataType(ATTRIBUTE_DATATYPE);
         MessageAttributeValue typeAttrVal = new MessageAttributeValue().withStringValue(EMAIL_TYPE)
                   .withDataType(ATTRIBUTE_DATATYPE);
         MessageAttributeValue firstNameAttrVal = new MessageAttributeValue().withStringValue(user.getFirstName())
                   .withDataType(ATTRIBUTE_DATATYPE);
         Object[][] messageAttributesMap = new Object[][] { { EMAIL_ATTRIBUTE, emailAttrVal },
                   { TYPE_ATTRIBUTE, typeAttrVal }, { FIRST_NAME_ATTRIBUTE, firstNameAttrVal },
                    };

         return Stream.of(messageAttributesMap)
                   .collect(Collectors.toMap(data -> (String) data[0], data -> (MessageAttributeValue) data[1]));

   }
   public static void uploadToS3(User user) {
       try {
            S3Object s3Object = s3Client().getObject(S3_USER_BUCKET, S3_USER_FILE_KEY);
            // parse the s3Object.
            List<User> dataToModify = readS3Object(s3Object);
            if (dataToModify.isEmpty())
                 throw new AmazonServiceException("Data not present in S3 Bucket");
            // Add the new user to List.
            dataToModify.add(user);
            File file = writeToTempFile(dataToModify, new File(TEMP_FILE_PATH));
            s3Client().deleteObject(S3_USER_BUCKET, S3_USER_FILE_KEY);

            log.info("Uploading the modified Json file to S3 with bucketname [{}] and key [{}]", S3_USER_BUCKET,
                       S3_USER_FILE_KEY);
            s3Client().putObject(S3_USER_BUCKET, S3_USER_FILE_KEY, file);
            log.info("File Successfully Uploaded [{}]", file);

       } catch (AmazonServiceException e) {
            log.error("Unable to either parse the user.json or its not available");

       } catch (Exception e) {
            log.error("Unexpected Exception occurred.");
       }


 }

 private static List<User> readS3Object(S3Object s3Object) {
       try {
            return gson.fromJson(new InputStreamReader(s3Object.getObjectContent(), UTF_8), List.class);
       } catch (JsonSyntaxException | JsonIOException e) {
            log.error("Unable to parse the S3 Object");
       }
       return Collections.emptyList();

 }

 private static File writeToTempFile(List<User> userList, File tempFile) {

     try (FileWriter fileWriter = new FileWriter(tempFile)) {
          gson.toJson(userList, fileWriter);

     } catch (IOException | JsonIOException e) {
          log.error("Unable to create temporary File");
     }
     return tempFile;

}




}




