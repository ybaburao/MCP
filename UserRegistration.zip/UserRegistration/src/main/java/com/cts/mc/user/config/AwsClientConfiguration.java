package com.cts.mc.user.config;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

public class AwsClientConfiguration  {


	private static final String AWS_SERVICE_KEY = "AKIAI323T3CGES2X3GQA";
	private static final String AWS_SERVICE_SECRET = "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";


	private AwsClientConfiguration() {

	}

	public static AWSCredentials credentials() {
		return new BasicAWSCredentials(AWS_SERVICE_KEY, AWS_SERVICE_SECRET);
	}

    public static AmazonSQS sqsClient() {
          return AmazonSQSClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials()))
                    .withRegion(Regions.US_EAST_1).build();
    }

    public static AmazonS3 s3Client() {
          return AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials()))
                    .withRegion(Regions.US_EAST_1).build();
    }



}

