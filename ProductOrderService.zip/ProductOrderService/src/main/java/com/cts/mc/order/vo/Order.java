package com.cts.mc.order.vo;

import java.util.List;

public class Order {
	  private String emailId;
	  private String orderCode;
	    private String name;
	     private List<Product> items;
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getOrderCode() {
			return orderCode;
		}
		public void setOrderCode(String orderCode) {
			this.orderCode = orderCode;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public List<Product> getItems() {
			return items;
		}
		public void setItems(List<Product> items) {
			this.items = items;
		}
	
	
}