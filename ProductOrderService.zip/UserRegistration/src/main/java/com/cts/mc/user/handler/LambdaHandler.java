package com.cts.mc.user.handler;

import static com.cts.mc.user.sqs.UserSQSPublishService.publishToSQS;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SNSEvent;
import com.cts.mc.user.vo.User;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class LambdaHandler implements RequestHandler<SNSEvent, String> {

    private static final String SUCCESSFUL = "User is registered Successfully published to Queue with details.";

    private static Logger log = LoggerFactory.getLogger(LambdaHandler.class);

    private static final String EMPTY = "";



    @Override

    public String handleRequest(SNSEvent request, Context context) {
          log.info("Registration started : [{}]", LocalDateTime.now());
          String userDetails = request.getRecords().get(0).getSNS().getMessage();
          try {
               User user = retrieveUser(userDetails);
               log.info("Registering User FirstName : [{}]", user.getFirstName());
               log.info("Registering User LastName : [{}]", user.getLastName());
               log.info("Registering User UserId : [{}]", user.getUserId());
               log.info("Registering User EmailId : [{}]", user.getEmail());
               publishToSQS(user);
               log.info("Successfully published the message");

          } catch (AmazonServiceException e) {
               log.error("Unable to process further due to sudden interruption");
          } catch (Exception e) {
               log.error("ExceptionOccurred while processing SNS Event : [{}] at [{}] with exception {}", userDetails,
                          LocalDateTime.now(), e);
          }
          return SUCCESSFUL;
    }

    private User retrieveUser(String userDetails) {
          try {
               Gson gson = new Gson();
               log.info("URL Encoded JSON automatically Decoded : [{}]", userDetails);
               return gson.fromJson(userDetails, User.class);
          } catch (JsonSyntaxException e) {
               log.error("Unable to Parse String to User Object.");
               throw new AmazonServiceException("Unable to Retrieve User");
          }

    }



}

